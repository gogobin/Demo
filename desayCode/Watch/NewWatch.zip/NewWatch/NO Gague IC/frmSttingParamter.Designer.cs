﻿namespace IC.NOGagueIC.SW
{
    partial class frmSttingParamter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dgvTitleSetting = new CCWin.SkinControl.SkinDataGridView();
            this.dataGridViewTextBoxColumn72 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn84 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn87 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn88 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn90 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn25 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn85 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgvConnection = new CCWin.SkinControl.SkinDataGridView();
            this.dataGridViewCheckBoxColumn2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn47 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn48 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn49 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn50 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn10 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.label17 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabControlTestFunction = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.skinGroupBox6ODCP = new CCWin.SkinControl.SkinGroupBox();
            this.txtOdcpStepCurrent = new System.Windows.Forms.TextBox();
            this.skinLabel28 = new CCWin.SkinControl.SkinLabel();
            this.txtOdcpTimeMax = new System.Windows.Forms.TextBox();
            this.txtOdcpTimeMin = new System.Windows.Forms.TextBox();
            this.skinLabel16 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel21 = new CCWin.SkinControl.SkinLabel();
            this.txtODCPRecoverChargeCurrent = new System.Windows.Forms.TextBox();
            this.txtODCPRecoverChargeVoltage = new System.Windows.Forms.TextBox();
            this.txtODCPRecoverDelay = new System.Windows.Forms.TextBox();
            this.txtODCPProtectCondition = new System.Windows.Forms.TextBox();
            this.cboODCPRecoverMode = new System.Windows.Forms.ComboBox();
            this.cboODCPProtectMode = new System.Windows.Forms.ComboBox();
            this.chkODCP = new CCWin.SkinControl.SkinCheckBox();
            this.skinLabel13 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel8 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel9 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel10 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel11 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel12 = new CCWin.SkinControl.SkinLabel();
            this.skinGroupBoxOCCP = new CCWin.SkinControl.SkinGroupBox();
            this.txtOCCPRecoverDischargeCurrent = new System.Windows.Forms.TextBox();
            this.skinTextBox1 = new System.Windows.Forms.TextBox();
            this.txtOCCPProtectMode = new System.Windows.Forms.TextBox();
            this.cboOCCPRecoverMode = new System.Windows.Forms.ComboBox();
            this.cboOCCPProtectMode = new System.Windows.Forms.ComboBox();
            this.chkOCCP = new CCWin.SkinControl.SkinCheckBox();
            this.skinLabel7 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel6 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel5 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel4 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel3 = new CCWin.SkinControl.SkinLabel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dgvTestStep = new CCWin.SkinControl.SkinDataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtExplain = new System.Windows.Forms.TextBox();
            this.skinGroupBox1 = new CCWin.SkinControl.SkinGroupBox();
            this.cboStation = new System.Windows.Forms.ComboBox();
            this.cboTestDevice = new System.Windows.Forms.ComboBox();
            this.skinLabel20 = new CCWin.SkinControl.SkinLabel();
            this.cbo运输方式 = new System.Windows.Forms.ComboBox();
            this.skinLabel19 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel18 = new CCWin.SkinControl.SkinLabel();
            this.cboBQType = new System.Windows.Forms.ComboBox();
            this.skinLabel17 = new CCWin.SkinControl.SkinLabel();
            this.txtStepName = new System.Windows.Forms.TextBox();
            this.txtBoxSetpIndex = new System.Windows.Forms.TextBox();
            this.skinLabel1 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel2 = new CCWin.SkinControl.SkinLabel();
            this.btnExit = new CCWin.SkinControl.SkinButton();
            this.btnEditTheNexStep = new CCWin.SkinControl.SkinButton();
            this.btnEdittheLatStep = new CCWin.SkinControl.SkinButton();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabControlParaSetting = new System.Windows.Forms.TabControl();
            this.tabPageRange = new System.Windows.Forms.TabPage();
            this.cboIDRange = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.skinLabel27 = new CCWin.SkinControl.SkinLabel();
            this.tabPageParaSettingConnect = new System.Windows.Forms.TabPage();
            this.chkSManualstart = new CCWin.SkinControl.SkinCheckBox();
            this.chkStartSCanBarcode = new CCWin.SkinControl.SkinCheckBox();
            this.chkClearCellVoltage = new CCWin.SkinControl.SkinCheckBox();
            this.skinLabel15 = new CCWin.SkinControl.SkinLabel();
            this.chkWakeUPN = new CCWin.SkinControl.SkinCheckBox();
            this.chkWakeUPR = new CCWin.SkinControl.SkinCheckBox();
            this.txtCellVoltage = new System.Windows.Forms.TextBox();
            this.skinLabel14 = new CCWin.SkinControl.SkinLabel();
            this.tabPageODCP = new System.Windows.Forms.TabPage();
            this.tabPageOCCP = new System.Windows.Forms.TabPage();
            this.tabPageCellProtect = new System.Windows.Forms.TabPage();
            this.txtCellProtectStepVol = new System.Windows.Forms.TextBox();
            this.skinLabel26 = new CCWin.SkinControl.SkinLabel();
            this.txtCellProtectRecoveryTime = new System.Windows.Forms.TextBox();
            this.skinLabel25 = new CCWin.SkinControl.SkinLabel();
            this.chkCellProtectRecoveryWUN = new CCWin.SkinControl.SkinCheckBox();
            this.chkCellProtectRecoveryWUR = new CCWin.SkinControl.SkinCheckBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.skinLabel24 = new CCWin.SkinControl.SkinLabel();
            this.txtCellProtectTimeMax = new System.Windows.Forms.TextBox();
            this.txtCellProtectTimeMin = new System.Windows.Forms.TextBox();
            this.skinLabel22 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel23 = new CCWin.SkinControl.SkinLabel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTitleSetting)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvConnection)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.skinGroupBox6ODCP.SuspendLayout();
            this.skinGroupBoxOCCP.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTestStep)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.skinGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabControlParaSetting.SuspendLayout();
            this.tabPageRange.SuspendLayout();
            this.tabPageParaSettingConnect.SuspendLayout();
            this.tabPageODCP.SuspendLayout();
            this.tabPageOCCP.SuspendLayout();
            this.tabPageCellProtect.SuspendLayout();
            this.SuspendLayout();
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Iterm";
            this.columnHeader1.Width = 101;
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(0, 0);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(200, 100);
            this.tabPage3.TabIndex = 0;
            // 
            // dgvTitleSetting
            // 
            this.dgvTitleSetting.AllowUserToAddRows = false;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(253)))));
            this.dgvTitleSetting.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle17;
            this.dgvTitleSetting.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgvTitleSetting.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvTitleSetting.ColumnFont = null;
            this.dgvTitleSetting.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.NullValue = null;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTitleSetting.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dgvTitleSetting.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTitleSetting.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn72,
            this.dataGridViewTextBoxColumn84,
            this.dataGridViewTextBoxColumn87,
            this.dataGridViewTextBoxColumn88,
            this.dataGridViewTextBoxColumn90,
            this.dataGridViewCheckBoxColumn25,
            this.dataGridViewTextBoxColumn85});
            this.dgvTitleSetting.ColumnSelectForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(188)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTitleSetting.DefaultCellStyle = dataGridViewCellStyle21;
            this.dgvTitleSetting.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTitleSetting.EnableHeadersVisualStyles = false;
            this.dgvTitleSetting.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dgvTitleSetting.HeadFont = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvTitleSetting.HeadSelectForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgvTitleSetting.Location = new System.Drawing.Point(3, 19);
            this.dgvTitleSetting.Name = "dgvTitleSetting";
            this.dgvTitleSetting.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvTitleSetting.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgvTitleSetting.RowsDefaultCellStyle = dataGridViewCellStyle22;
            this.dgvTitleSetting.RowTemplate.Height = 23;
            this.dgvTitleSetting.Size = new System.Drawing.Size(1170, 484);
            this.dgvTitleSetting.TabIndex = 54;
            this.dgvTitleSetting.TitleBack = null;
            this.dgvTitleSetting.TitleBackColorBegin = System.Drawing.Color.White;
            this.dgvTitleSetting.TitleBackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(196)))), ((int)(((byte)(242)))));
            // 
            // dataGridViewTextBoxColumn72
            // 
            this.dataGridViewTextBoxColumn72.HeaderText = "Iterm";
            this.dataGridViewTextBoxColumn72.Name = "dataGridViewTextBoxColumn72";
            this.dataGridViewTextBoxColumn72.ReadOnly = true;
            this.dataGridViewTextBoxColumn72.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn72.Width = 200;
            // 
            // dataGridViewTextBoxColumn84
            // 
            this.dataGridViewTextBoxColumn84.HeaderText = "Value";
            this.dataGridViewTextBoxColumn84.Name = "dataGridViewTextBoxColumn84";
            // 
            // dataGridViewTextBoxColumn87
            // 
            dataGridViewCellStyle19.Format = "N2";
            dataGridViewCellStyle19.NullValue = "1";
            this.dataGridViewTextBoxColumn87.DefaultCellStyle = dataGridViewCellStyle19;
            this.dataGridViewTextBoxColumn87.HeaderText = "Retry";
            this.dataGridViewTextBoxColumn87.Name = "dataGridViewTextBoxColumn87";
            this.dataGridViewTextBoxColumn87.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn88
            // 
            dataGridViewCellStyle20.Format = "N2";
            dataGridViewCellStyle20.NullValue = "10";
            this.dataGridViewTextBoxColumn88.DefaultCellStyle = dataGridViewCellStyle20;
            this.dataGridViewTextBoxColumn88.HeaderText = "Delay(ms)";
            this.dataGridViewTextBoxColumn88.Name = "dataGridViewTextBoxColumn88";
            this.dataGridViewTextBoxColumn88.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn90
            // 
            this.dataGridViewTextBoxColumn90.HeaderText = "ErrorCode";
            this.dataGridViewTextBoxColumn90.Name = "dataGridViewTextBoxColumn90";
            this.dataGridViewTextBoxColumn90.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewCheckBoxColumn25
            // 
            this.dataGridViewCheckBoxColumn25.HeaderText = "Go on";
            this.dataGridViewCheckBoxColumn25.Name = "dataGridViewCheckBoxColumn25";
            this.dataGridViewCheckBoxColumn25.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn25.Width = 80;
            // 
            // dataGridViewTextBoxColumn85
            // 
            this.dataGridViewTextBoxColumn85.HeaderText = "RmarK";
            this.dataGridViewTextBoxColumn85.Name = "dataGridViewTextBoxColumn85";
            this.dataGridViewTextBoxColumn85.Width = 300;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(46, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 17);
            this.label4.TabIndex = 1;
            this.label4.Text = "BQ类型:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 26);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1176, 562);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Commuication";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgvConnection);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1170, 556);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "电压单位为:mV;电阻单位:KΩ";
            // 
            // dgvConnection
            // 
            this.dgvConnection.AllowUserToAddRows = false;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(253)))));
            this.dgvConnection.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle23;
            this.dgvConnection.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgvConnection.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvConnection.ColumnFont = null;
            this.dgvConnection.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvConnection.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.dgvConnection.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvConnection.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewCheckBoxColumn2,
            this.dataGridViewTextBoxColumn33,
            this.dataGridViewTextBoxColumn47,
            this.dataGridViewTextBoxColumn48,
            this.dataGridViewTextBoxColumn49,
            this.dataGridViewTextBoxColumn50,
            this.dataGridViewCheckBoxColumn10});
            this.dgvConnection.ColumnSelectForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(188)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvConnection.DefaultCellStyle = dataGridViewCellStyle27;
            this.dgvConnection.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvConnection.EnableHeadersVisualStyles = false;
            this.dgvConnection.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dgvConnection.HeadFont = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvConnection.HeadSelectForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgvConnection.Location = new System.Drawing.Point(3, 17);
            this.dgvConnection.Name = "dgvConnection";
            this.dgvConnection.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvConnection.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgvConnection.RowsDefaultCellStyle = dataGridViewCellStyle28;
            this.dgvConnection.RowTemplate.Height = 23;
            this.dgvConnection.Size = new System.Drawing.Size(1164, 536);
            this.dgvConnection.TabIndex = 56;
            this.dgvConnection.TitleBack = null;
            this.dgvConnection.TitleBackColorBegin = System.Drawing.Color.White;
            this.dgvConnection.TitleBackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(196)))), ((int)(((byte)(242)))));
            // 
            // dataGridViewCheckBoxColumn2
            // 
            this.dataGridViewCheckBoxColumn2.HeaderText = "Test";
            this.dataGridViewCheckBoxColumn2.Name = "dataGridViewCheckBoxColumn2";
            this.dataGridViewCheckBoxColumn2.Width = 50;
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.HeaderText = "Iterm";
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            this.dataGridViewTextBoxColumn33.ReadOnly = true;
            this.dataGridViewTextBoxColumn33.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn33.Width = 200;
            // 
            // dataGridViewTextBoxColumn47
            // 
            this.dataGridViewTextBoxColumn47.HeaderText = "Min";
            this.dataGridViewTextBoxColumn47.Name = "dataGridViewTextBoxColumn47";
            this.dataGridViewTextBoxColumn47.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn48
            // 
            this.dataGridViewTextBoxColumn48.HeaderText = "Max";
            this.dataGridViewTextBoxColumn48.Name = "dataGridViewTextBoxColumn48";
            this.dataGridViewTextBoxColumn48.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn49
            // 
            dataGridViewCellStyle25.Format = "N2";
            dataGridViewCellStyle25.NullValue = "1";
            this.dataGridViewTextBoxColumn49.DefaultCellStyle = dataGridViewCellStyle25;
            this.dataGridViewTextBoxColumn49.HeaderText = "Retry";
            this.dataGridViewTextBoxColumn49.Name = "dataGridViewTextBoxColumn49";
            this.dataGridViewTextBoxColumn49.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn49.Width = 50;
            // 
            // dataGridViewTextBoxColumn50
            // 
            dataGridViewCellStyle26.Format = "N2";
            dataGridViewCellStyle26.NullValue = "10";
            this.dataGridViewTextBoxColumn50.DefaultCellStyle = dataGridViewCellStyle26;
            this.dataGridViewTextBoxColumn50.HeaderText = "Delay(ms)";
            this.dataGridViewTextBoxColumn50.Name = "dataGridViewTextBoxColumn50";
            this.dataGridViewTextBoxColumn50.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn50.Width = 80;
            // 
            // dataGridViewCheckBoxColumn10
            // 
            this.dataGridViewCheckBoxColumn10.HeaderText = "Go on";
            this.dataGridViewCheckBoxColumn10.Name = "dataGridViewCheckBoxColumn10";
            this.dataGridViewCheckBoxColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn10.Width = 80;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(20, 30);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(0, 12);
            this.label17.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.tabControlTestFunction);
            this.tabPage4.Location = new System.Drawing.Point(4, 26);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1176, 562);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Function";
            // 
            // tabControlTestFunction
            // 
            this.tabControlTestFunction.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlTestFunction.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabControlTestFunction.Location = new System.Drawing.Point(0, 0);
            this.tabControlTestFunction.Name = "tabControlTestFunction";
            this.tabControlTestFunction.SelectedIndex = 0;
            this.tabControlTestFunction.Size = new System.Drawing.Size(1176, 562);
            this.tabControlTestFunction.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.tabControl3);
            this.tabPage5.Location = new System.Drawing.Point(4, 26);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1176, 562);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "SMBus/I2C EE Test";
            // 
            // tabControl3
            // 
            this.tabControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl3.Location = new System.Drawing.Point(0, 0);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(1176, 562);
            this.tabControl3.TabIndex = 1;
            // 
            // skinGroupBox6ODCP
            // 
            this.skinGroupBox6ODCP.BackColor = System.Drawing.Color.Transparent;
            this.skinGroupBox6ODCP.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.skinGroupBox6ODCP.Controls.Add(this.txtOdcpStepCurrent);
            this.skinGroupBox6ODCP.Controls.Add(this.skinLabel28);
            this.skinGroupBox6ODCP.Controls.Add(this.txtOdcpTimeMax);
            this.skinGroupBox6ODCP.Controls.Add(this.txtOdcpTimeMin);
            this.skinGroupBox6ODCP.Controls.Add(this.skinLabel16);
            this.skinGroupBox6ODCP.Controls.Add(this.skinLabel21);
            this.skinGroupBox6ODCP.Controls.Add(this.txtODCPRecoverChargeCurrent);
            this.skinGroupBox6ODCP.Controls.Add(this.txtODCPRecoverChargeVoltage);
            this.skinGroupBox6ODCP.Controls.Add(this.txtODCPRecoverDelay);
            this.skinGroupBox6ODCP.Controls.Add(this.txtODCPProtectCondition);
            this.skinGroupBox6ODCP.Controls.Add(this.cboODCPRecoverMode);
            this.skinGroupBox6ODCP.Controls.Add(this.cboODCPProtectMode);
            this.skinGroupBox6ODCP.Controls.Add(this.chkODCP);
            this.skinGroupBox6ODCP.Controls.Add(this.skinLabel13);
            this.skinGroupBox6ODCP.Controls.Add(this.skinLabel8);
            this.skinGroupBox6ODCP.Controls.Add(this.skinLabel9);
            this.skinGroupBox6ODCP.Controls.Add(this.skinLabel10);
            this.skinGroupBox6ODCP.Controls.Add(this.skinLabel11);
            this.skinGroupBox6ODCP.Controls.Add(this.skinLabel12);
            this.skinGroupBox6ODCP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinGroupBox6ODCP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.skinGroupBox6ODCP.ForeColor = System.Drawing.Color.Blue;
            this.skinGroupBox6ODCP.Location = new System.Drawing.Point(0, 0);
            this.skinGroupBox6ODCP.Name = "skinGroupBox6ODCP";
            this.skinGroupBox6ODCP.RectBackColor = System.Drawing.Color.White;
            this.skinGroupBox6ODCP.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinGroupBox6ODCP.Size = new System.Drawing.Size(871, 321);
            this.skinGroupBox6ODCP.TabIndex = 67;
            this.skinGroupBox6ODCP.TabStop = false;
            this.skinGroupBox6ODCP.TitleBorderColor = System.Drawing.Color.Blue;
            this.skinGroupBox6ODCP.TitleRectBackColor = System.Drawing.Color.White;
            this.skinGroupBox6ODCP.TitleRoundStyle = CCWin.SkinClass.RoundStyle.All;
            // 
            // txtOdcpStepCurrent
            // 
            this.txtOdcpStepCurrent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOdcpStepCurrent.Location = new System.Drawing.Point(211, 19);
            this.txtOdcpStepCurrent.Name = "txtOdcpStepCurrent";
            this.txtOdcpStepCurrent.Size = new System.Drawing.Size(164, 26);
            this.txtOdcpStepCurrent.TabIndex = 86;
            // 
            // skinLabel28
            // 
            this.skinLabel28.AutoSize = true;
            this.skinLabel28.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel28.BorderColor = System.Drawing.Color.White;
            this.skinLabel28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel28.Location = new System.Drawing.Point(-2, 22);
            this.skinLabel28.Name = "skinLabel28";
            this.skinLabel28.Size = new System.Drawing.Size(216, 20);
            this.skinLabel28.TabIndex = 85;
            this.skinLabel28.Text = "Current Add Step(Unit:mA)：";
            // 
            // txtOdcpTimeMax
            // 
            this.txtOdcpTimeMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOdcpTimeMax.Location = new System.Drawing.Point(195, 196);
            this.txtOdcpTimeMax.Name = "txtOdcpTimeMax";
            this.txtOdcpTimeMax.Size = new System.Drawing.Size(180, 26);
            this.txtOdcpTimeMax.TabIndex = 72;
            // 
            // txtOdcpTimeMin
            // 
            this.txtOdcpTimeMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOdcpTimeMin.Location = new System.Drawing.Point(195, 157);
            this.txtOdcpTimeMin.Name = "txtOdcpTimeMin";
            this.txtOdcpTimeMin.Size = new System.Drawing.Size(180, 26);
            this.txtOdcpTimeMin.TabIndex = 71;
            // 
            // skinLabel16
            // 
            this.skinLabel16.AutoSize = true;
            this.skinLabel16.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel16.BorderColor = System.Drawing.Color.White;
            this.skinLabel16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel16.Location = new System.Drawing.Point(9, 199);
            this.skinLabel16.Name = "skinLabel16";
            this.skinLabel16.Size = new System.Drawing.Size(144, 20);
            this.skinLabel16.TabIndex = 70;
            this.skinLabel16.Text = "Time Max(Unit:ms):";
            // 
            // skinLabel21
            // 
            this.skinLabel21.AutoSize = true;
            this.skinLabel21.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel21.BorderColor = System.Drawing.Color.White;
            this.skinLabel21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel21.Location = new System.Drawing.Point(9, 163);
            this.skinLabel21.Name = "skinLabel21";
            this.skinLabel21.Size = new System.Drawing.Size(140, 20);
            this.skinLabel21.TabIndex = 69;
            this.skinLabel21.Text = "Time Min(Unit:ms):";
            // 
            // txtODCPRecoverChargeCurrent
            // 
            this.txtODCPRecoverChargeCurrent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtODCPRecoverChargeCurrent.Location = new System.Drawing.Point(624, 136);
            this.txtODCPRecoverChargeCurrent.Name = "txtODCPRecoverChargeCurrent";
            this.txtODCPRecoverChargeCurrent.Size = new System.Drawing.Size(180, 26);
            this.txtODCPRecoverChargeCurrent.TabIndex = 68;
            this.txtODCPRecoverChargeCurrent.Visible = false;
            // 
            // txtODCPRecoverChargeVoltage
            // 
            this.txtODCPRecoverChargeVoltage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtODCPRecoverChargeVoltage.Location = new System.Drawing.Point(624, 98);
            this.txtODCPRecoverChargeVoltage.Name = "txtODCPRecoverChargeVoltage";
            this.txtODCPRecoverChargeVoltage.Size = new System.Drawing.Size(180, 26);
            this.txtODCPRecoverChargeVoltage.TabIndex = 67;
            this.txtODCPRecoverChargeVoltage.Visible = false;
            // 
            // txtODCPRecoverDelay
            // 
            this.txtODCPRecoverDelay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtODCPRecoverDelay.Location = new System.Drawing.Point(624, 57);
            this.txtODCPRecoverDelay.Name = "txtODCPRecoverDelay";
            this.txtODCPRecoverDelay.Size = new System.Drawing.Size(180, 26);
            this.txtODCPRecoverDelay.TabIndex = 66;
            this.txtODCPRecoverDelay.Visible = false;
            // 
            // txtODCPProtectCondition
            // 
            this.txtODCPProtectCondition.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtODCPProtectCondition.Location = new System.Drawing.Point(195, 110);
            this.txtODCPProtectCondition.Name = "txtODCPProtectCondition";
            this.txtODCPProtectCondition.Size = new System.Drawing.Size(180, 26);
            this.txtODCPProtectCondition.TabIndex = 65;
            // 
            // cboODCPRecoverMode
            // 
            this.cboODCPRecoverMode.AutoCompleteCustomSource.AddRange(new string[] {
            "Check Flag",
            "Check Voltage",
            "Check Voltage"});
            this.cboODCPRecoverMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboODCPRecoverMode.FormattingEnabled = true;
            this.cboODCPRecoverMode.Items.AddRange(new object[] {
            "Charge Recovery",
            "Auto Recovery"});
            this.cboODCPRecoverMode.Location = new System.Drawing.Point(624, 21);
            this.cboODCPRecoverMode.Name = "cboODCPRecoverMode";
            this.cboODCPRecoverMode.Size = new System.Drawing.Size(180, 28);
            this.cboODCPRecoverMode.TabIndex = 18;
            this.cboODCPRecoverMode.Visible = false;
            this.cboODCPRecoverMode.SelectedIndexChanged += new System.EventHandler(this.cboODCPRecoverMode_SelectedIndexChanged);
            // 
            // cboODCPProtectMode
            // 
            this.cboODCPProtectMode.AutoCompleteCustomSource.AddRange(new string[] {
            "Check Flag",
            "Check Voltage",
            "Check Voltage"});
            this.cboODCPProtectMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboODCPProtectMode.FormattingEnabled = true;
            this.cboODCPProtectMode.Items.AddRange(new object[] {
            "Check Voltage",
            "Check Current"});
            this.cboODCPProtectMode.Location = new System.Drawing.Point(195, 66);
            this.cboODCPProtectMode.Name = "cboODCPProtectMode";
            this.cboODCPProtectMode.Size = new System.Drawing.Size(180, 28);
            this.cboODCPProtectMode.TabIndex = 17;
            this.cboODCPProtectMode.SelectedIndexChanged += new System.EventHandler(this.cboODCPProtectMode_SelectedIndexChanged_1);
            // 
            // chkODCP
            // 
            this.chkODCP.AutoSize = true;
            this.chkODCP.BackColor = System.Drawing.Color.Transparent;
            this.chkODCP.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.chkODCP.DownBack = null;
            this.chkODCP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkODCP.Location = new System.Drawing.Point(689, 289);
            this.chkODCP.MouseBack = null;
            this.chkODCP.Name = "chkODCP";
            this.chkODCP.NormlBack = null;
            this.chkODCP.SelectedDownBack = null;
            this.chkODCP.SelectedMouseBack = null;
            this.chkODCP.SelectedNormlBack = null;
            this.chkODCP.Size = new System.Drawing.Size(97, 24);
            this.chkODCP.TabIndex = 16;
            this.chkODCP.Text = "In Protect";
            this.chkODCP.UseVisualStyleBackColor = false;
            this.chkODCP.Visible = false;
            // 
            // skinLabel13
            // 
            this.skinLabel13.AutoSize = true;
            this.skinLabel13.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel13.BorderColor = System.Drawing.Color.White;
            this.skinLabel13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel13.Location = new System.Drawing.Point(402, 139);
            this.skinLabel13.Name = "skinLabel13";
            this.skinLabel13.Size = new System.Drawing.Size(155, 20);
            this.skinLabel13.TabIndex = 14;
            this.skinLabel13.Text = "Delay Time(Unit:ms):";
            this.skinLabel13.Visible = false;
            // 
            // skinLabel8
            // 
            this.skinLabel8.AutoSize = true;
            this.skinLabel8.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel8.BorderColor = System.Drawing.Color.White;
            this.skinLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel8.Location = new System.Drawing.Point(402, 106);
            this.skinLabel8.Name = "skinLabel8";
            this.skinLabel8.Size = new System.Drawing.Size(155, 20);
            this.skinLabel8.TabIndex = 12;
            this.skinLabel8.Text = "Delay Time(Unit:ms):";
            this.skinLabel8.Visible = false;
            // 
            // skinLabel9
            // 
            this.skinLabel9.AutoSize = true;
            this.skinLabel9.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel9.BorderColor = System.Drawing.Color.White;
            this.skinLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel9.Location = new System.Drawing.Point(402, 65);
            this.skinLabel9.Name = "skinLabel9";
            this.skinLabel9.Size = new System.Drawing.Size(155, 20);
            this.skinLabel9.TabIndex = 10;
            this.skinLabel9.Text = "Delay Time(Unit:ms):";
            this.skinLabel9.Visible = false;
            // 
            // skinLabel10
            // 
            this.skinLabel10.AutoSize = true;
            this.skinLabel10.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel10.BorderColor = System.Drawing.Color.White;
            this.skinLabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel10.Location = new System.Drawing.Point(6, 110);
            this.skinLabel10.Name = "skinLabel10";
            this.skinLabel10.Size = new System.Drawing.Size(164, 20);
            this.skinLabel10.TabIndex = 8;
            this.skinLabel10.Text = "Voltage Min(Unit:mV):";
            this.skinLabel10.Visible = false;
            // 
            // skinLabel11
            // 
            this.skinLabel11.AutoSize = true;
            this.skinLabel11.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel11.BorderColor = System.Drawing.Color.White;
            this.skinLabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel11.Location = new System.Drawing.Point(400, 26);
            this.skinLabel11.Name = "skinLabel11";
            this.skinLabel11.Size = new System.Drawing.Size(123, 20);
            this.skinLabel11.TabIndex = 6;
            this.skinLabel11.Text = "Recovery Mode:";
            this.skinLabel11.Visible = false;
            // 
            // skinLabel12
            // 
            this.skinLabel12.AutoSize = true;
            this.skinLabel12.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel12.BorderColor = System.Drawing.Color.White;
            this.skinLabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel12.Location = new System.Drawing.Point(6, 70);
            this.skinLabel12.Name = "skinLabel12";
            this.skinLabel12.Size = new System.Drawing.Size(157, 20);
            this.skinLabel12.TabIndex = 5;
            this.skinLabel12.Text = "Check Protect Mode:";
            // 
            // skinGroupBoxOCCP
            // 
            this.skinGroupBoxOCCP.BackColor = System.Drawing.Color.Transparent;
            this.skinGroupBoxOCCP.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.skinGroupBoxOCCP.Controls.Add(this.txtOCCPRecoverDischargeCurrent);
            this.skinGroupBoxOCCP.Controls.Add(this.skinTextBox1);
            this.skinGroupBoxOCCP.Controls.Add(this.txtOCCPProtectMode);
            this.skinGroupBoxOCCP.Controls.Add(this.cboOCCPRecoverMode);
            this.skinGroupBoxOCCP.Controls.Add(this.cboOCCPProtectMode);
            this.skinGroupBoxOCCP.Controls.Add(this.chkOCCP);
            this.skinGroupBoxOCCP.Controls.Add(this.skinLabel7);
            this.skinGroupBoxOCCP.Controls.Add(this.skinLabel6);
            this.skinGroupBoxOCCP.Controls.Add(this.skinLabel5);
            this.skinGroupBoxOCCP.Controls.Add(this.skinLabel4);
            this.skinGroupBoxOCCP.Controls.Add(this.skinLabel3);
            this.skinGroupBoxOCCP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinGroupBoxOCCP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.skinGroupBoxOCCP.ForeColor = System.Drawing.Color.Blue;
            this.skinGroupBoxOCCP.Location = new System.Drawing.Point(0, 0);
            this.skinGroupBoxOCCP.Name = "skinGroupBoxOCCP";
            this.skinGroupBoxOCCP.RectBackColor = System.Drawing.Color.White;
            this.skinGroupBoxOCCP.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinGroupBoxOCCP.Size = new System.Drawing.Size(871, 321);
            this.skinGroupBoxOCCP.TabIndex = 66;
            this.skinGroupBoxOCCP.TabStop = false;
            this.skinGroupBoxOCCP.TitleBorderColor = System.Drawing.Color.Blue;
            this.skinGroupBoxOCCP.TitleRectBackColor = System.Drawing.Color.White;
            this.skinGroupBoxOCCP.TitleRoundStyle = CCWin.SkinClass.RoundStyle.All;
            // 
            // txtOCCPRecoverDischargeCurrent
            // 
            this.txtOCCPRecoverDischargeCurrent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOCCPRecoverDischargeCurrent.Location = new System.Drawing.Point(624, 109);
            this.txtOCCPRecoverDischargeCurrent.Name = "txtOCCPRecoverDischargeCurrent";
            this.txtOCCPRecoverDischargeCurrent.Size = new System.Drawing.Size(180, 26);
            this.txtOCCPRecoverDischargeCurrent.TabIndex = 67;
            this.txtOCCPRecoverDischargeCurrent.Visible = false;
            // 
            // skinTextBox1
            // 
            this.skinTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.skinTextBox1.Location = new System.Drawing.Point(624, 64);
            this.skinTextBox1.Name = "skinTextBox1";
            this.skinTextBox1.Size = new System.Drawing.Size(180, 26);
            this.skinTextBox1.TabIndex = 66;
            this.skinTextBox1.Visible = false;
            // 
            // txtOCCPProtectMode
            // 
            this.txtOCCPProtectMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOCCPProtectMode.Location = new System.Drawing.Point(195, 62);
            this.txtOCCPProtectMode.Name = "txtOCCPProtectMode";
            this.txtOCCPProtectMode.Size = new System.Drawing.Size(180, 26);
            this.txtOCCPProtectMode.TabIndex = 64;
            // 
            // cboOCCPRecoverMode
            // 
            this.cboOCCPRecoverMode.AutoCompleteCustomSource.AddRange(new string[] {
            "Check Flag",
            "Check Voltage",
            "Check Voltage"});
            this.cboOCCPRecoverMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboOCCPRecoverMode.FormattingEnabled = true;
            this.cboOCCPRecoverMode.Items.AddRange(new object[] {
            "DisCharge Recovery",
            "Auto Recovery"});
            this.cboOCCPRecoverMode.Location = new System.Drawing.Point(624, 20);
            this.cboOCCPRecoverMode.Name = "cboOCCPRecoverMode";
            this.cboOCCPRecoverMode.Size = new System.Drawing.Size(180, 28);
            this.cboOCCPRecoverMode.TabIndex = 18;
            this.cboOCCPRecoverMode.Visible = false;
            this.cboOCCPRecoverMode.SelectedIndexChanged += new System.EventHandler(this.cboOCCPRecoverMode_SelectedIndexChanged_1);
            // 
            // cboOCCPProtectMode
            // 
            this.cboOCCPProtectMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboOCCPProtectMode.FormattingEnabled = true;
            this.cboOCCPProtectMode.Items.AddRange(new object[] {
            "Check Voltage",
            "Check Current"});
            this.cboOCCPProtectMode.Location = new System.Drawing.Point(195, 25);
            this.cboOCCPProtectMode.Name = "cboOCCPProtectMode";
            this.cboOCCPProtectMode.Size = new System.Drawing.Size(180, 28);
            this.cboOCCPProtectMode.TabIndex = 15;
            this.cboOCCPProtectMode.SelectedIndexChanged += new System.EventHandler(this.cboOCCPProtectMode_SelectedIndexChanged);
            // 
            // chkOCCP
            // 
            this.chkOCCP.AutoSize = true;
            this.chkOCCP.BackColor = System.Drawing.Color.Transparent;
            this.chkOCCP.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.chkOCCP.DownBack = null;
            this.chkOCCP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOCCP.Location = new System.Drawing.Point(195, 107);
            this.chkOCCP.MouseBack = null;
            this.chkOCCP.Name = "chkOCCP";
            this.chkOCCP.NormlBack = null;
            this.chkOCCP.SelectedDownBack = null;
            this.chkOCCP.SelectedMouseBack = null;
            this.chkOCCP.SelectedNormlBack = null;
            this.chkOCCP.Size = new System.Drawing.Size(97, 24);
            this.chkOCCP.TabIndex = 14;
            this.chkOCCP.Text = "In Protect";
            this.chkOCCP.UseVisualStyleBackColor = false;
            this.chkOCCP.Visible = false;
            // 
            // skinLabel7
            // 
            this.skinLabel7.AutoSize = true;
            this.skinLabel7.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel7.BorderColor = System.Drawing.Color.White;
            this.skinLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel7.Location = new System.Drawing.Point(402, 106);
            this.skinLabel7.Name = "skinLabel7";
            this.skinLabel7.Size = new System.Drawing.Size(155, 20);
            this.skinLabel7.TabIndex = 12;
            this.skinLabel7.Text = "Delay Time(Unit:ms):";
            this.skinLabel7.Visible = false;
            // 
            // skinLabel6
            // 
            this.skinLabel6.AutoSize = true;
            this.skinLabel6.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel6.BorderColor = System.Drawing.Color.White;
            this.skinLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel6.Location = new System.Drawing.Point(402, 65);
            this.skinLabel6.Name = "skinLabel6";
            this.skinLabel6.Size = new System.Drawing.Size(155, 20);
            this.skinLabel6.TabIndex = 10;
            this.skinLabel6.Text = "Delay Time(Unit:ms):";
            this.skinLabel6.Visible = false;
            // 
            // skinLabel5
            // 
            this.skinLabel5.AutoSize = true;
            this.skinLabel5.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel5.BorderColor = System.Drawing.Color.White;
            this.skinLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel5.Location = new System.Drawing.Point(6, 65);
            this.skinLabel5.Name = "skinLabel5";
            this.skinLabel5.Size = new System.Drawing.Size(164, 20);
            this.skinLabel5.TabIndex = 8;
            this.skinLabel5.Text = "Voltage Min(Unit:mV):";
            // 
            // skinLabel4
            // 
            this.skinLabel4.AutoSize = true;
            this.skinLabel4.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel4.BorderColor = System.Drawing.Color.White;
            this.skinLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel4.Location = new System.Drawing.Point(400, 26);
            this.skinLabel4.Name = "skinLabel4";
            this.skinLabel4.Size = new System.Drawing.Size(123, 20);
            this.skinLabel4.TabIndex = 6;
            this.skinLabel4.Text = "Recovery Mode:";
            this.skinLabel4.Visible = false;
            // 
            // skinLabel3
            // 
            this.skinLabel3.AutoSize = true;
            this.skinLabel3.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel3.BorderColor = System.Drawing.Color.White;
            this.skinLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel3.Location = new System.Drawing.Point(6, 25);
            this.skinLabel3.Name = "skinLabel3";
            this.skinLabel3.Size = new System.Drawing.Size(157, 20);
            this.skinLabel3.TabIndex = 5;
            this.skinLabel3.Text = "Check Protect Mode:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dgvTestStep);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(0, 128);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(879, 129);
            this.groupBox3.TabIndex = 59;
            this.groupBox3.TabStop = false;
            // 
            // dgvTestStep
            // 
            this.dgvTestStep.AllowUserToAddRows = false;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(253)))));
            this.dgvTestStep.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle29;
            this.dgvTestStep.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvTestStep.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgvTestStep.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvTestStep.ColumnFont = null;
            this.dgvTestStep.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle30.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle30.NullValue = null;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTestStep.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle30;
            this.dgvTestStep.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTestStep.ColumnSelectForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle31.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle31.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle31.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle31.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(188)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle31.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTestStep.DefaultCellStyle = dataGridViewCellStyle31;
            this.dgvTestStep.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTestStep.EnableHeadersVisualStyles = false;
            this.dgvTestStep.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dgvTestStep.HeadFont = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvTestStep.HeadSelectForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgvTestStep.Location = new System.Drawing.Point(3, 17);
            this.dgvTestStep.Name = "dgvTestStep";
            this.dgvTestStep.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvTestStep.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle32.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgvTestStep.RowsDefaultCellStyle = dataGridViewCellStyle32;
            this.dgvTestStep.RowTemplate.Height = 23;
            this.dgvTestStep.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvTestStep.Size = new System.Drawing.Size(873, 109);
            this.dgvTestStep.TabIndex = 57;
            this.dgvTestStep.TitleBack = null;
            this.dgvTestStep.TitleBackColorBegin = System.Drawing.Color.White;
            this.dgvTestStep.TitleBackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(196)))), ((int)(((byte)(242)))));
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtExplain);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(879, 78);
            this.groupBox1.TabIndex = 58;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "说明:";
            // 
            // txtExplain
            // 
            this.txtExplain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtExplain.Font = new System.Drawing.Font("Arial Unicode MS", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtExplain.Location = new System.Drawing.Point(3, 17);
            this.txtExplain.Multiline = true;
            this.txtExplain.Name = "txtExplain";
            this.txtExplain.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtExplain.Size = new System.Drawing.Size(873, 58);
            this.txtExplain.TabIndex = 0;
            // 
            // skinGroupBox1
            // 
            this.skinGroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.skinGroupBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.skinGroupBox1.Controls.Add(this.cboStation);
            this.skinGroupBox1.Controls.Add(this.cboTestDevice);
            this.skinGroupBox1.Controls.Add(this.skinLabel20);
            this.skinGroupBox1.Controls.Add(this.cbo运输方式);
            this.skinGroupBox1.Controls.Add(this.skinLabel19);
            this.skinGroupBox1.Controls.Add(this.skinLabel18);
            this.skinGroupBox1.Controls.Add(this.cboBQType);
            this.skinGroupBox1.Controls.Add(this.skinLabel17);
            this.skinGroupBox1.Controls.Add(this.txtStepName);
            this.skinGroupBox1.Controls.Add(this.txtBoxSetpIndex);
            this.skinGroupBox1.Controls.Add(this.skinLabel1);
            this.skinGroupBox1.Controls.Add(this.skinLabel2);
            this.skinGroupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.skinGroupBox1.ForeColor = System.Drawing.Color.Blue;
            this.skinGroupBox1.Location = new System.Drawing.Point(0, 78);
            this.skinGroupBox1.Name = "skinGroupBox1";
            this.skinGroupBox1.RectBackColor = System.Drawing.Color.White;
            this.skinGroupBox1.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinGroupBox1.Size = new System.Drawing.Size(879, 50);
            this.skinGroupBox1.TabIndex = 63;
            this.skinGroupBox1.TabStop = false;
            this.skinGroupBox1.TitleBorderColor = System.Drawing.Color.Red;
            this.skinGroupBox1.TitleRectBackColor = System.Drawing.Color.White;
            this.skinGroupBox1.TitleRoundStyle = CCWin.SkinClass.RoundStyle.All;
            // 
            // cboStation
            // 
            this.cboStation.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cboStation.FormattingEnabled = true;
            this.cboStation.Location = new System.Drawing.Point(331, 53);
            this.cboStation.Name = "cboStation";
            this.cboStation.Size = new System.Drawing.Size(86, 29);
            this.cboStation.TabIndex = 72;
            this.cboStation.Visible = false;
            // 
            // cboTestDevice
            // 
            this.cboTestDevice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTestDevice.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cboTestDevice.FormattingEnabled = true;
            this.cboTestDevice.Items.AddRange(new object[] {
            "空运",
            "陆运",
            "海运"});
            this.cboTestDevice.Location = new System.Drawing.Point(664, 51);
            this.cboTestDevice.Name = "cboTestDevice";
            this.cboTestDevice.Size = new System.Drawing.Size(148, 29);
            this.cboTestDevice.TabIndex = 71;
            this.cboTestDevice.Visible = false;
            // 
            // skinLabel20
            // 
            this.skinLabel20.AutoSize = true;
            this.skinLabel20.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel20.BorderColor = System.Drawing.Color.White;
            this.skinLabel20.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.skinLabel20.Location = new System.Drawing.Point(580, 56);
            this.skinLabel20.Name = "skinLabel20";
            this.skinLabel20.Size = new System.Drawing.Size(78, 21);
            this.skinLabel20.TabIndex = 70;
            this.skinLabel20.Text = "测试设备:";
            this.skinLabel20.Visible = false;
            // 
            // cbo运输方式
            // 
            this.cbo运输方式.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbo运输方式.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cbo运输方式.FormattingEnabled = true;
            this.cbo运输方式.Items.AddRange(new object[] {
            global::IC.NOGagueIC.SW.Properties.Resources.FilePath,
            "陆运",
            "空运"});
            this.cbo运输方式.Location = new System.Drawing.Point(507, 53);
            this.cbo运输方式.Name = "cbo运输方式";
            this.cbo运输方式.Size = new System.Drawing.Size(61, 29);
            this.cbo运输方式.TabIndex = 69;
            this.cbo运输方式.Visible = false;
            // 
            // skinLabel19
            // 
            this.skinLabel19.AutoSize = true;
            this.skinLabel19.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel19.BorderColor = System.Drawing.Color.White;
            this.skinLabel19.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.skinLabel19.Location = new System.Drawing.Point(423, 56);
            this.skinLabel19.Name = "skinLabel19";
            this.skinLabel19.Size = new System.Drawing.Size(78, 21);
            this.skinLabel19.TabIndex = 68;
            this.skinLabel19.Text = "运输方式:";
            this.skinLabel19.Visible = false;
            // 
            // skinLabel18
            // 
            this.skinLabel18.AutoSize = true;
            this.skinLabel18.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel18.BorderColor = System.Drawing.Color.White;
            this.skinLabel18.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.skinLabel18.Location = new System.Drawing.Point(280, 56);
            this.skinLabel18.Name = "skinLabel18";
            this.skinLabel18.Size = new System.Drawing.Size(46, 21);
            this.skinLabel18.TabIndex = 66;
            this.skinLabel18.Text = "工序:";
            this.skinLabel18.Visible = false;
            // 
            // cboBQType
            // 
            this.cboBQType.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cboBQType.FormattingEnabled = true;
            this.cboBQType.Location = new System.Drawing.Point(119, 53);
            this.cboBQType.Name = "cboBQType";
            this.cboBQType.Size = new System.Drawing.Size(155, 29);
            this.cboBQType.TabIndex = 65;
            this.cboBQType.Visible = false;
            // 
            // skinLabel17
            // 
            this.skinLabel17.AutoSize = true;
            this.skinLabel17.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel17.BorderColor = System.Drawing.Color.White;
            this.skinLabel17.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.skinLabel17.Location = new System.Drawing.Point(26, 59);
            this.skinLabel17.Name = "skinLabel17";
            this.skinLabel17.Size = new System.Drawing.Size(69, 21);
            this.skinLabel17.TabIndex = 64;
            this.skinLabel17.Text = "BQ类型:";
            this.skinLabel17.Visible = false;
            // 
            // txtStepName
            // 
            this.txtStepName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStepName.Location = new System.Drawing.Point(119, 12);
            this.txtStepName.Name = "txtStepName";
            this.txtStepName.Size = new System.Drawing.Size(429, 26);
            this.txtStepName.TabIndex = 63;
            // 
            // txtBoxSetpIndex
            // 
            this.txtBoxSetpIndex.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxSetpIndex.Location = new System.Drawing.Point(656, 12);
            this.txtBoxSetpIndex.Name = "txtBoxSetpIndex";
            this.txtBoxSetpIndex.ReadOnly = true;
            this.txtBoxSetpIndex.Size = new System.Drawing.Size(100, 26);
            this.txtBoxSetpIndex.TabIndex = 62;
            // 
            // skinLabel1
            // 
            this.skinLabel1.AutoSize = true;
            this.skinLabel1.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel1.BorderColor = System.Drawing.Color.White;
            this.skinLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel1.Location = new System.Drawing.Point(27, 17);
            this.skinLabel1.Name = "skinLabel1";
            this.skinLabel1.Size = new System.Drawing.Size(82, 17);
            this.skinLabel1.TabIndex = 58;
            this.skinLabel1.Text = "Step Name:";
            // 
            // skinLabel2
            // 
            this.skinLabel2.AutoSize = true;
            this.skinLabel2.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel2.BorderColor = System.Drawing.Color.White;
            this.skinLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel2.Location = new System.Drawing.Point(567, 17);
            this.skinLabel2.Name = "skinLabel2";
            this.skinLabel2.Size = new System.Drawing.Size(78, 17);
            this.skinLabel2.TabIndex = 60;
            this.skinLabel2.Text = "Step Index:";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Transparent;
            this.btnExit.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnExit.ControlState = CCWin.SkinClass.ControlState.Hover;
            this.btnExit.DownBack = null;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.Black;
            this.btnExit.Location = new System.Drawing.Point(331, 263);
            this.btnExit.MouseBack = null;
            this.btnExit.Name = "btnExit";
            this.btnExit.NormlBack = null;
            this.btnExit.Size = new System.Drawing.Size(182, 30);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Update  Parameter";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnEditTheNexStep
            // 
            this.btnEditTheNexStep.BackColor = System.Drawing.Color.Transparent;
            this.btnEditTheNexStep.ControlState = CCWin.SkinClass.ControlState.Hover;
            this.btnEditTheNexStep.DownBack = null;
            this.btnEditTheNexStep.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditTheNexStep.ForeColor = System.Drawing.Color.Black;
            this.btnEditTheNexStep.Location = new System.Drawing.Point(173, 263);
            this.btnEditTheNexStep.MouseBack = null;
            this.btnEditTheNexStep.Name = "btnEditTheNexStep";
            this.btnEditTheNexStep.NormlBack = null;
            this.btnEditTheNexStep.Size = new System.Drawing.Size(150, 30);
            this.btnEditTheNexStep.TabIndex = 1;
            this.btnEditTheNexStep.Text = "Next Step ";
            this.btnEditTheNexStep.UseVisualStyleBackColor = false;
            this.btnEditTheNexStep.Click += new System.EventHandler(this.btnEditTheNexStep_Click);
            // 
            // btnEdittheLatStep
            // 
            this.btnEdittheLatStep.BackColor = System.Drawing.Color.Transparent;
            this.btnEdittheLatStep.ControlState = CCWin.SkinClass.ControlState.Hover;
            this.btnEdittheLatStep.DownBack = null;
            this.btnEdittheLatStep.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdittheLatStep.ForeColor = System.Drawing.Color.Black;
            this.btnEdittheLatStep.Location = new System.Drawing.Point(17, 263);
            this.btnEdittheLatStep.MouseBack = null;
            this.btnEdittheLatStep.Name = "btnEdittheLatStep";
            this.btnEdittheLatStep.NormlBack = null;
            this.btnEdittheLatStep.Size = new System.Drawing.Size(150, 30);
            this.btnEdittheLatStep.TabIndex = 0;
            this.btnEdittheLatStep.Text = "Upper Step ";
            this.btnEdittheLatStep.UseVisualStyleBackColor = false;
            this.btnEdittheLatStep.Click += new System.EventHandler(this.btnEdittheLatStep_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.treeView1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1381, 658);
            this.splitContainer1.SplitterDistance = 498;
            this.splitContainer1.TabIndex = 6;
            // 
            // treeView1
            // 
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.treeView1.Location = new System.Drawing.Point(0, 0);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(498, 658);
            this.treeView1.TabIndex = 0;
            this.treeView1.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeView1_NodeMouseClick);
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.panel1);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.tabControlParaSetting);
            this.splitContainer2.Size = new System.Drawing.Size(879, 658);
            this.splitContainer2.SplitterDistance = 307;
            this.splitContainer2.TabIndex = 58;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.btnExit);
            this.panel1.Controls.Add(this.skinGroupBox1);
            this.panel1.Controls.Add(this.btnEditTheNexStep);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.btnEdittheLatStep);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(879, 307);
            this.panel1.TabIndex = 0;
            // 
            // tabControlParaSetting
            // 
            this.tabControlParaSetting.Controls.Add(this.tabPageRange);
            this.tabControlParaSetting.Controls.Add(this.tabPageParaSettingConnect);
            this.tabControlParaSetting.Controls.Add(this.tabPageODCP);
            this.tabControlParaSetting.Controls.Add(this.tabPageOCCP);
            this.tabControlParaSetting.Controls.Add(this.tabPageCellProtect);
            this.tabControlParaSetting.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlParaSetting.Location = new System.Drawing.Point(0, 0);
            this.tabControlParaSetting.Name = "tabControlParaSetting";
            this.tabControlParaSetting.SelectedIndex = 0;
            this.tabControlParaSetting.Size = new System.Drawing.Size(879, 347);
            this.tabControlParaSetting.TabIndex = 58;
            // 
            // tabPageRange
            // 
            this.tabPageRange.Controls.Add(this.cboIDRange);
            this.tabPageRange.Controls.Add(this.textBox1);
            this.tabPageRange.Controls.Add(this.skinLabel27);
            this.tabPageRange.Location = new System.Drawing.Point(4, 22);
            this.tabPageRange.Name = "tabPageRange";
            this.tabPageRange.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageRange.Size = new System.Drawing.Size(871, 321);
            this.tabPageRange.TabIndex = 0;
            this.tabPageRange.Text = "Range";
            this.tabPageRange.UseVisualStyleBackColor = true;
            // 
            // cboIDRange
            // 
            this.cboIDRange.FormattingEnabled = true;
            this.cboIDRange.Items.AddRange(new object[] {
            "50K",
            "500K",
            "1000K"});
            this.cboIDRange.Location = new System.Drawing.Point(60, 16);
            this.cboIDRange.Name = "cboIDRange";
            this.cboIDRange.Size = new System.Drawing.Size(138, 20);
            this.cboIDRange.TabIndex = 83;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(497, 42);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(67, 26);
            this.textBox1.TabIndex = 81;
            // 
            // skinLabel27
            // 
            this.skinLabel27.AutoSize = true;
            this.skinLabel27.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel27.BorderColor = System.Drawing.Color.White;
            this.skinLabel27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel27.Location = new System.Drawing.Point(3, 16);
            this.skinLabel27.Name = "skinLabel27";
            this.skinLabel27.Size = new System.Drawing.Size(61, 20);
            this.skinLabel27.TabIndex = 80;
            this.skinLabel27.Text = "Range:";
            // 
            // tabPageParaSettingConnect
            // 
            this.tabPageParaSettingConnect.Controls.Add(this.chkSManualstart);
            this.tabPageParaSettingConnect.Controls.Add(this.chkStartSCanBarcode);
            this.tabPageParaSettingConnect.Controls.Add(this.chkClearCellVoltage);
            this.tabPageParaSettingConnect.Controls.Add(this.skinLabel15);
            this.tabPageParaSettingConnect.Controls.Add(this.chkWakeUPN);
            this.tabPageParaSettingConnect.Controls.Add(this.chkWakeUPR);
            this.tabPageParaSettingConnect.Controls.Add(this.txtCellVoltage);
            this.tabPageParaSettingConnect.Controls.Add(this.skinLabel14);
            this.tabPageParaSettingConnect.Location = new System.Drawing.Point(4, 22);
            this.tabPageParaSettingConnect.Name = "tabPageParaSettingConnect";
            this.tabPageParaSettingConnect.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageParaSettingConnect.Size = new System.Drawing.Size(871, 321);
            this.tabPageParaSettingConnect.TabIndex = 1;
            this.tabPageParaSettingConnect.Text = "Seting";
            this.tabPageParaSettingConnect.UseVisualStyleBackColor = true;
            // 
            // chkSManualstart
            // 
            this.chkSManualstart.AutoSize = true;
            this.chkSManualstart.BackColor = System.Drawing.Color.Transparent;
            this.chkSManualstart.ControlState = CCWin.SkinClass.ControlState.Focused;
            this.chkSManualstart.DownBack = null;
            this.chkSManualstart.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkSManualstart.Location = new System.Drawing.Point(13, 154);
            this.chkSManualstart.MouseBack = null;
            this.chkSManualstart.Name = "chkSManualstart";
            this.chkSManualstart.NormlBack = null;
            this.chkSManualstart.SelectedDownBack = null;
            this.chkSManualstart.SelectedMouseBack = null;
            this.chkSManualstart.SelectedNormlBack = null;
            this.chkSManualstart.Size = new System.Drawing.Size(92, 24);
            this.chkSManualstart.TabIndex = 82;
            this.chkSManualstart.Text = "手动启动";
            this.chkSManualstart.UseVisualStyleBackColor = false;
            this.chkSManualstart.Visible = false;
            // 
            // chkStartSCanBarcode
            // 
            this.chkStartSCanBarcode.AutoSize = true;
            this.chkStartSCanBarcode.BackColor = System.Drawing.Color.Transparent;
            this.chkStartSCanBarcode.ControlState = CCWin.SkinClass.ControlState.Focused;
            this.chkStartSCanBarcode.DownBack = null;
            this.chkStartSCanBarcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkStartSCanBarcode.Location = new System.Drawing.Point(13, 112);
            this.chkStartSCanBarcode.MouseBack = null;
            this.chkStartSCanBarcode.Name = "chkStartSCanBarcode";
            this.chkStartSCanBarcode.NormlBack = null;
            this.chkStartSCanBarcode.SelectedDownBack = null;
            this.chkStartSCanBarcode.SelectedMouseBack = null;
            this.chkStartSCanBarcode.SelectedNormlBack = null;
            this.chkStartSCanBarcode.Size = new System.Drawing.Size(92, 24);
            this.chkStartSCanBarcode.TabIndex = 81;
            this.chkStartSCanBarcode.Text = "扫码启动";
            this.chkStartSCanBarcode.UseVisualStyleBackColor = false;
            this.chkStartSCanBarcode.Visible = false;
            // 
            // chkClearCellVoltage
            // 
            this.chkClearCellVoltage.AutoSize = true;
            this.chkClearCellVoltage.BackColor = System.Drawing.Color.Transparent;
            this.chkClearCellVoltage.ControlState = CCWin.SkinClass.ControlState.Focused;
            this.chkClearCellVoltage.DownBack = null;
            this.chkClearCellVoltage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkClearCellVoltage.Location = new System.Drawing.Point(13, 62);
            this.chkClearCellVoltage.MouseBack = null;
            this.chkClearCellVoltage.Name = "chkClearCellVoltage";
            this.chkClearCellVoltage.NormlBack = null;
            this.chkClearCellVoltage.SelectedDownBack = null;
            this.chkClearCellVoltage.SelectedMouseBack = null;
            this.chkClearCellVoltage.SelectedNormlBack = null;
            this.chkClearCellVoltage.Size = new System.Drawing.Size(156, 24);
            this.chkClearCellVoltage.TabIndex = 80;
            this.chkClearCellVoltage.Text = "测试完成清空电压";
            this.chkClearCellVoltage.UseVisualStyleBackColor = false;
            // 
            // skinLabel15
            // 
            this.skinLabel15.AutoSize = true;
            this.skinLabel15.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel15.BorderColor = System.Drawing.Color.White;
            this.skinLabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel15.Location = new System.Drawing.Point(186, 24);
            this.skinLabel15.Name = "skinLabel15";
            this.skinLabel15.Size = new System.Drawing.Size(33, 20);
            this.skinLabel15.TabIndex = 79;
            this.skinLabel15.Text = "mV";
            this.skinLabel15.Visible = false;
            // 
            // chkWakeUPN
            // 
            this.chkWakeUPN.AutoSize = true;
            this.chkWakeUPN.BackColor = System.Drawing.Color.Transparent;
            this.chkWakeUPN.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.chkWakeUPN.DownBack = null;
            this.chkWakeUPN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkWakeUPN.Location = new System.Drawing.Point(395, 23);
            this.chkWakeUPN.MouseBack = null;
            this.chkWakeUPN.Name = "chkWakeUPN";
            this.chkWakeUPN.NormlBack = null;
            this.chkWakeUPN.SelectedDownBack = null;
            this.chkWakeUPN.SelectedMouseBack = null;
            this.chkWakeUPN.SelectedNormlBack = null;
            this.chkWakeUPN.Size = new System.Drawing.Size(114, 24);
            this.chkWakeUPN.TabIndex = 78;
            this.chkWakeUPN.Text = "Wake UP P-";
            this.chkWakeUPN.UseVisualStyleBackColor = false;
            this.chkWakeUPN.Visible = false;
            // 
            // chkWakeUPR
            // 
            this.chkWakeUPR.AutoSize = true;
            this.chkWakeUPR.BackColor = System.Drawing.Color.Transparent;
            this.chkWakeUPR.ControlState = CCWin.SkinClass.ControlState.Focused;
            this.chkWakeUPR.DownBack = null;
            this.chkWakeUPR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkWakeUPR.Location = new System.Drawing.Point(256, 22);
            this.chkWakeUPR.MouseBack = null;
            this.chkWakeUPR.Name = "chkWakeUPR";
            this.chkWakeUPR.NormlBack = null;
            this.chkWakeUPR.SelectedDownBack = null;
            this.chkWakeUPR.SelectedMouseBack = null;
            this.chkWakeUPR.SelectedNormlBack = null;
            this.chkWakeUPR.Size = new System.Drawing.Size(118, 24);
            this.chkWakeUPR.TabIndex = 77;
            this.chkWakeUPR.Text = "Wake UP P+";
            this.chkWakeUPR.UseVisualStyleBackColor = false;
            this.chkWakeUPR.Visible = false;
            // 
            // txtCellVoltage
            // 
            this.txtCellVoltage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCellVoltage.Location = new System.Drawing.Point(113, 21);
            this.txtCellVoltage.Name = "txtCellVoltage";
            this.txtCellVoltage.Size = new System.Drawing.Size(67, 26);
            this.txtCellVoltage.TabIndex = 67;
            // 
            // skinLabel14
            // 
            this.skinLabel14.AutoSize = true;
            this.skinLabel14.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel14.BorderColor = System.Drawing.Color.White;
            this.skinLabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel14.Location = new System.Drawing.Point(9, 24);
            this.skinLabel14.Name = "skinLabel14";
            this.skinLabel14.Size = new System.Drawing.Size(98, 20);
            this.skinLabel14.TabIndex = 66;
            this.skinLabel14.Text = "Cell Voltage:";
            // 
            // tabPageODCP
            // 
            this.tabPageODCP.Controls.Add(this.skinGroupBox6ODCP);
            this.tabPageODCP.Location = new System.Drawing.Point(4, 22);
            this.tabPageODCP.Name = "tabPageODCP";
            this.tabPageODCP.Size = new System.Drawing.Size(871, 321);
            this.tabPageODCP.TabIndex = 2;
            this.tabPageODCP.Text = "ODCP";
            this.tabPageODCP.UseVisualStyleBackColor = true;
            // 
            // tabPageOCCP
            // 
            this.tabPageOCCP.Controls.Add(this.skinGroupBoxOCCP);
            this.tabPageOCCP.Location = new System.Drawing.Point(4, 22);
            this.tabPageOCCP.Name = "tabPageOCCP";
            this.tabPageOCCP.Size = new System.Drawing.Size(871, 321);
            this.tabPageOCCP.TabIndex = 4;
            this.tabPageOCCP.Text = "OCCP";
            this.tabPageOCCP.UseVisualStyleBackColor = true;
            // 
            // tabPageCellProtect
            // 
            this.tabPageCellProtect.Controls.Add(this.txtCellProtectStepVol);
            this.tabPageCellProtect.Controls.Add(this.skinLabel26);
            this.tabPageCellProtect.Controls.Add(this.txtCellProtectRecoveryTime);
            this.tabPageCellProtect.Controls.Add(this.skinLabel25);
            this.tabPageCellProtect.Controls.Add(this.chkCellProtectRecoveryWUN);
            this.tabPageCellProtect.Controls.Add(this.chkCellProtectRecoveryWUR);
            this.tabPageCellProtect.Controls.Add(this.comboBox1);
            this.tabPageCellProtect.Controls.Add(this.skinLabel24);
            this.tabPageCellProtect.Controls.Add(this.txtCellProtectTimeMax);
            this.tabPageCellProtect.Controls.Add(this.txtCellProtectTimeMin);
            this.tabPageCellProtect.Controls.Add(this.skinLabel22);
            this.tabPageCellProtect.Controls.Add(this.skinLabel23);
            this.tabPageCellProtect.Location = new System.Drawing.Point(4, 22);
            this.tabPageCellProtect.Name = "tabPageCellProtect";
            this.tabPageCellProtect.Size = new System.Drawing.Size(871, 321);
            this.tabPageCellProtect.TabIndex = 5;
            this.tabPageCellProtect.Text = "Cell Protect";
            this.tabPageCellProtect.UseVisualStyleBackColor = true;
            // 
            // txtCellProtectStepVol
            // 
            this.txtCellProtectStepVol.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCellProtectStepVol.Location = new System.Drawing.Point(244, 11);
            this.txtCellProtectStepVol.Name = "txtCellProtectStepVol";
            this.txtCellProtectStepVol.Size = new System.Drawing.Size(180, 26);
            this.txtCellProtectStepVol.TabIndex = 84;
            // 
            // skinLabel26
            // 
            this.skinLabel26.AutoSize = true;
            this.skinLabel26.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel26.BorderColor = System.Drawing.Color.White;
            this.skinLabel26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel26.Location = new System.Drawing.Point(31, 14);
            this.skinLabel26.Name = "skinLabel26";
            this.skinLabel26.Size = new System.Drawing.Size(218, 20);
            this.skinLabel26.TabIndex = 83;
            this.skinLabel26.Text = "Voltage Add Step(Unit:mV)：";
            // 
            // txtCellProtectRecoveryTime
            // 
            this.txtCellProtectRecoveryTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCellProtectRecoveryTime.Location = new System.Drawing.Point(244, 143);
            this.txtCellProtectRecoveryTime.Name = "txtCellProtectRecoveryTime";
            this.txtCellProtectRecoveryTime.Size = new System.Drawing.Size(180, 26);
            this.txtCellProtectRecoveryTime.TabIndex = 82;
            // 
            // skinLabel25
            // 
            this.skinLabel25.AutoSize = true;
            this.skinLabel25.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel25.BorderColor = System.Drawing.Color.White;
            this.skinLabel25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel25.Location = new System.Drawing.Point(9, 146);
            this.skinLabel25.Name = "skinLabel25";
            this.skinLabel25.Size = new System.Drawing.Size(241, 20);
            this.skinLabel25.TabIndex = 81;
            this.skinLabel25.Text = "AUTO Recovery Time(Unit:ms)：";
            // 
            // chkCellProtectRecoveryWUN
            // 
            this.chkCellProtectRecoveryWUN.AutoSize = true;
            this.chkCellProtectRecoveryWUN.BackColor = System.Drawing.Color.Transparent;
            this.chkCellProtectRecoveryWUN.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.chkCellProtectRecoveryWUN.DownBack = null;
            this.chkCellProtectRecoveryWUN.Enabled = false;
            this.chkCellProtectRecoveryWUN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCellProtectRecoveryWUN.Location = new System.Drawing.Point(596, 85);
            this.chkCellProtectRecoveryWUN.MouseBack = null;
            this.chkCellProtectRecoveryWUN.Name = "chkCellProtectRecoveryWUN";
            this.chkCellProtectRecoveryWUN.NormlBack = null;
            this.chkCellProtectRecoveryWUN.SelectedDownBack = null;
            this.chkCellProtectRecoveryWUN.SelectedMouseBack = null;
            this.chkCellProtectRecoveryWUN.SelectedNormlBack = null;
            this.chkCellProtectRecoveryWUN.Size = new System.Drawing.Size(114, 24);
            this.chkCellProtectRecoveryWUN.TabIndex = 80;
            this.chkCellProtectRecoveryWUN.Text = "Wake UP P-";
            this.chkCellProtectRecoveryWUN.UseVisualStyleBackColor = false;
            this.chkCellProtectRecoveryWUN.Visible = false;
            // 
            // chkCellProtectRecoveryWUR
            // 
            this.chkCellProtectRecoveryWUR.AutoSize = true;
            this.chkCellProtectRecoveryWUR.BackColor = System.Drawing.Color.Transparent;
            this.chkCellProtectRecoveryWUR.ControlState = CCWin.SkinClass.ControlState.Focused;
            this.chkCellProtectRecoveryWUR.DownBack = null;
            this.chkCellProtectRecoveryWUR.Enabled = false;
            this.chkCellProtectRecoveryWUR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCellProtectRecoveryWUR.Location = new System.Drawing.Point(596, 49);
            this.chkCellProtectRecoveryWUR.MouseBack = null;
            this.chkCellProtectRecoveryWUR.Name = "chkCellProtectRecoveryWUR";
            this.chkCellProtectRecoveryWUR.NormlBack = null;
            this.chkCellProtectRecoveryWUR.SelectedDownBack = null;
            this.chkCellProtectRecoveryWUR.SelectedMouseBack = null;
            this.chkCellProtectRecoveryWUR.SelectedNormlBack = null;
            this.chkCellProtectRecoveryWUR.Size = new System.Drawing.Size(118, 24);
            this.chkCellProtectRecoveryWUR.TabIndex = 79;
            this.chkCellProtectRecoveryWUR.Text = "Wake UP P+";
            this.chkCellProtectRecoveryWUR.UseVisualStyleBackColor = false;
            this.chkCellProtectRecoveryWUR.Visible = false;
            // 
            // comboBox1
            // 
            this.comboBox1.AutoCompleteCustomSource.AddRange(new string[] {
            "Check Flag",
            "Check Voltage",
            "Check Voltage"});
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "WakeUP Recovery",
            "Auto Recovery"});
            this.comboBox1.Location = new System.Drawing.Point(244, 113);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(180, 20);
            this.comboBox1.TabIndex = 78;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // skinLabel24
            // 
            this.skinLabel24.AutoSize = true;
            this.skinLabel24.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel24.BorderColor = System.Drawing.Color.White;
            this.skinLabel24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel24.Location = new System.Drawing.Point(111, 113);
            this.skinLabel24.Name = "skinLabel24";
            this.skinLabel24.Size = new System.Drawing.Size(123, 20);
            this.skinLabel24.TabIndex = 77;
            this.skinLabel24.Text = "Recovery Mode:";
            // 
            // txtCellProtectTimeMax
            // 
            this.txtCellProtectTimeMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCellProtectTimeMax.Location = new System.Drawing.Point(244, 79);
            this.txtCellProtectTimeMax.Name = "txtCellProtectTimeMax";
            this.txtCellProtectTimeMax.Size = new System.Drawing.Size(180, 26);
            this.txtCellProtectTimeMax.TabIndex = 76;
            // 
            // txtCellProtectTimeMin
            // 
            this.txtCellProtectTimeMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCellProtectTimeMin.Location = new System.Drawing.Point(244, 47);
            this.txtCellProtectTimeMin.Name = "txtCellProtectTimeMin";
            this.txtCellProtectTimeMin.Size = new System.Drawing.Size(180, 26);
            this.txtCellProtectTimeMin.TabIndex = 75;
            // 
            // skinLabel22
            // 
            this.skinLabel22.AutoSize = true;
            this.skinLabel22.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel22.BorderColor = System.Drawing.Color.White;
            this.skinLabel22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel22.Location = new System.Drawing.Point(27, 83);
            this.skinLabel22.Name = "skinLabel22";
            this.skinLabel22.Size = new System.Drawing.Size(211, 20);
            this.skinLabel22.TabIndex = 74;
            this.skinLabel22.Text = "Protect Time Max(Unit:ms)：";
            // 
            // skinLabel23
            // 
            this.skinLabel23.AutoSize = true;
            this.skinLabel23.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel23.BorderColor = System.Drawing.Color.White;
            this.skinLabel23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel23.Location = new System.Drawing.Point(31, 50);
            this.skinLabel23.Name = "skinLabel23";
            this.skinLabel23.Size = new System.Drawing.Size(207, 20);
            this.skinLabel23.TabIndex = 73;
            this.skinLabel23.Text = "Protect Time Min(Unit:ms)：";
            // 
            // frmSttingParamter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1381, 658);
            this.Controls.Add(this.splitContainer1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSttingParamter";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Setting Paramter";
            this.Load += new System.EventHandler(this.frmSttingParamter_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTitleSetting)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvConnection)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.skinGroupBox6ODCP.ResumeLayout(false);
            this.skinGroupBox6ODCP.PerformLayout();
            this.skinGroupBoxOCCP.ResumeLayout(false);
            this.skinGroupBoxOCCP.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTestStep)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.skinGroupBox1.ResumeLayout(false);
            this.skinGroupBox1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.tabControlParaSetting.ResumeLayout(false);
            this.tabPageRange.ResumeLayout(false);
            this.tabPageRange.PerformLayout();
            this.tabPageParaSettingConnect.ResumeLayout(false);
            this.tabPageParaSettingConnect.PerformLayout();
            this.tabPageODCP.ResumeLayout(false);
            this.tabPageOCCP.ResumeLayout(false);
            this.tabPageCellProtect.ResumeLayout(false);
            this.tabPageCellProtect.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion


        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label4;
   
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;

        private System.Windows.Forms.TabControl tabControlTestFunction;
        private CCWin.SkinControl.SkinDataGridView dgvConnection;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn47;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn48;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn49;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn50;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn10;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label17;
        private CCWin.SkinControl.SkinDataGridView dgvTitleSetting;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn72;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn84;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn87;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn88;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn90;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn85;
        private System.Windows.Forms.TabControl tabControl3;
        private CCWin.SkinControl.SkinButton btnEditTheNexStep;
        private CCWin.SkinControl.SkinButton btnEdittheLatStep;
        public CCWin.SkinControl.SkinDataGridView dgvTestStep;
        private CCWin.SkinControl.SkinLabel skinLabel2;
        private CCWin.SkinControl.SkinLabel skinLabel1;
        private CCWin.SkinControl.SkinGroupBox skinGroupBox1;
        private CCWin.SkinControl.SkinGroupBox skinGroupBoxOCCP;
        private CCWin.SkinControl.SkinLabel skinLabel4;
        private CCWin.SkinControl.SkinLabel skinLabel3;
        private CCWin.SkinControl.SkinLabel skinLabel5;
        private CCWin.SkinControl.SkinLabel skinLabel7;
        private CCWin.SkinControl.SkinLabel skinLabel6;
        private CCWin.SkinControl.SkinGroupBox skinGroupBox6ODCP;
        private CCWin.SkinControl.SkinLabel skinLabel13;
        private CCWin.SkinControl.SkinLabel skinLabel8;
        private CCWin.SkinControl.SkinLabel skinLabel9;
        private CCWin.SkinControl.SkinLabel skinLabel10;
        private CCWin.SkinControl.SkinLabel skinLabel11;
        private CCWin.SkinControl.SkinLabel skinLabel12;
        private CCWin.SkinControl.SkinCheckBox chkOCCP;
        private CCWin.SkinControl.SkinButton btnExit;
        private System.Windows.Forms.ComboBox cboODCPRecoverMode;
        private System.Windows.Forms.ComboBox cboODCPProtectMode;
        private System.Windows.Forms.ComboBox cboOCCPRecoverMode;
        private System.Windows.Forms.ComboBox cboOCCPProtectMode;
        private System.Windows.Forms.TextBox txtODCPRecoverChargeCurrent;
        private System.Windows.Forms.TextBox txtODCPRecoverChargeVoltage;
        private System.Windows.Forms.TextBox txtODCPRecoverDelay;
        private System.Windows.Forms.TextBox txtODCPProtectCondition;
        private System.Windows.Forms.TextBox txtOCCPRecoverDischargeCurrent;
        private System.Windows.Forms.TextBox skinTextBox1;
        private System.Windows.Forms.TextBox txtOCCPProtectMode;
        private System.Windows.Forms.TextBox txtStepName;
        private System.Windows.Forms.TextBox txtBoxSetpIndex;
        private CCWin.SkinControl.SkinLabel skinLabel18;
        private System.Windows.Forms.ComboBox cboBQType;
        private CCWin.SkinControl.SkinLabel skinLabel17;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtExplain;
        private System.Windows.Forms.ComboBox cbo运输方式;
        private CCWin.SkinControl.SkinLabel skinLabel19;
        private System.Windows.Forms.ComboBox cboTestDevice;
        private CCWin.SkinControl.SkinLabel skinLabel20;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabControl tabControlParaSetting;
        private System.Windows.Forms.TabPage tabPageRange;
        private System.Windows.Forms.TabPage tabPageParaSettingConnect;
        private System.Windows.Forms.TabPage tabPageODCP;
        private System.Windows.Forms.TabPage tabPageOCCP;
        private System.Windows.Forms.TabPage tabPageCellProtect;
        private System.Windows.Forms.ComboBox cboStation;
        private CCWin.SkinControl.SkinLabel skinLabel15;
        private CCWin.SkinControl.SkinCheckBox chkWakeUPN;
        private CCWin.SkinControl.SkinCheckBox chkWakeUPR;
        private System.Windows.Forms.TextBox txtCellVoltage;
        private CCWin.SkinControl.SkinLabel skinLabel14;
        private System.Windows.Forms.TextBox txtOdcpTimeMax;
        private System.Windows.Forms.TextBox txtOdcpTimeMin;
        private CCWin.SkinControl.SkinLabel skinLabel16;
        private CCWin.SkinControl.SkinLabel skinLabel21;
        private CCWin.SkinControl.SkinCheckBox chkODCP;
        private System.Windows.Forms.TextBox txtCellProtectRecoveryTime;
        private CCWin.SkinControl.SkinLabel skinLabel25;
        private CCWin.SkinControl.SkinCheckBox chkCellProtectRecoveryWUN;
        private CCWin.SkinControl.SkinCheckBox chkCellProtectRecoveryWUR;
        private System.Windows.Forms.ComboBox comboBox1;
        private CCWin.SkinControl.SkinLabel skinLabel24;
        private System.Windows.Forms.TextBox txtCellProtectTimeMax;
        private System.Windows.Forms.TextBox txtCellProtectTimeMin;
        private CCWin.SkinControl.SkinLabel skinLabel22;
        private CCWin.SkinControl.SkinLabel skinLabel23;
        private System.Windows.Forms.ComboBox cboIDRange;
        private System.Windows.Forms.TextBox textBox1;
        private CCWin.SkinControl.SkinLabel skinLabel27;
        private System.Windows.Forms.TextBox txtOdcpStepCurrent;
        private CCWin.SkinControl.SkinLabel skinLabel28;
        private System.Windows.Forms.TextBox txtCellProtectStepVol;
        private CCWin.SkinControl.SkinLabel skinLabel26;
        private CCWin.SkinControl.SkinCheckBox chkClearCellVoltage;
        private CCWin.SkinControl.SkinCheckBox chkSManualstart;
        private CCWin.SkinControl.SkinCheckBox chkStartSCanBarcode;
        private System.Windows.Forms.TreeView treeView1;

    }
}