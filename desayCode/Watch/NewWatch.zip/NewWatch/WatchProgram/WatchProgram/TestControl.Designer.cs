﻿
namespace WatchProgram
{
    partial class TestControl
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.dgvTest = new CCWin.SkinControl.SkinDataGridView();
            this.Col_TestKey = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_Channel1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_Channel2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_Channel3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_Channel4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.Channel4 = new System.Windows.Forms.Label();
            this.Channel3 = new System.Windows.Forms.Label();
            this.Channel2 = new System.Windows.Forms.Label();
            this.Channel1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.labPass_Channel1 = new System.Windows.Forms.Label();
            this.labPass_Channel2 = new System.Windows.Forms.Label();
            this.labPass_Channel3 = new System.Windows.Forms.Label();
            this.labPass_Channel4 = new System.Windows.Forms.Label();
            this.labSUM_Channel4 = new System.Windows.Forms.Label();
            this.labSUM_Channel3 = new System.Windows.Forms.Label();
            this.labSUM_Channel2 = new System.Windows.Forms.Label();
            this.labSUM_Channel1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lab_Channel1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTest)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.dgvTest, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1311, 668);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // dgvTest
            // 
            this.dgvTest.AllowUserToAddRows = false;
            this.dgvTest.AllowUserToDeleteRows = false;
            this.dgvTest.AllowUserToResizeColumns = false;
            this.dgvTest.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(253)))));
            this.dgvTest.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvTest.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgvTest.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvTest.ColumnFont = null;
            this.dgvTest.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTest.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvTest.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTest.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Col_TestKey,
            this.Col_Channel1,
            this.Col_Channel2,
            this.Col_Channel3,
            this.Col_Channel4});
            this.dgvTest.ColumnSelectForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(188)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTest.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvTest.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTest.EnableHeadersVisualStyles = false;
            this.dgvTest.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dgvTest.HeadFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.dgvTest.HeadSelectForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgvTest.Location = new System.Drawing.Point(3, 136);
            this.dgvTest.Name = "dgvTest";
            this.dgvTest.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvTest.RowHeadersVisible = false;
            this.dgvTest.RowHeadersWidth = 51;
            this.dgvTest.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgvTest.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvTest.RowTemplate.Height = 23;
            this.dgvTest.Size = new System.Drawing.Size(1305, 529);
            this.dgvTest.TabIndex = 0;
            this.dgvTest.TitleBack = null;
            this.dgvTest.TitleBackColorBegin = System.Drawing.Color.White;
            this.dgvTest.TitleBackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(196)))), ((int)(((byte)(242)))));
            // 
            // Col_TestKey
            // 
            this.Col_TestKey.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Col_TestKey.HeaderText = "Testkey";
            this.Col_TestKey.MinimumWidth = 6;
            this.Col_TestKey.Name = "Col_TestKey";
            this.Col_TestKey.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Col_Channel1
            // 
            this.Col_Channel1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Col_Channel1.HeaderText = "Channel1";
            this.Col_Channel1.MinimumWidth = 6;
            this.Col_Channel1.Name = "Col_Channel1";
            this.Col_Channel1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Col_Channel2
            // 
            this.Col_Channel2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Col_Channel2.HeaderText = "Channel2";
            this.Col_Channel2.MinimumWidth = 6;
            this.Col_Channel2.Name = "Col_Channel2";
            this.Col_Channel2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Col_Channel3
            // 
            this.Col_Channel3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Col_Channel3.HeaderText = "Channel3";
            this.Col_Channel3.MinimumWidth = 6;
            this.Col_Channel3.Name = "Col_Channel3";
            this.Col_Channel3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Col_Channel4
            // 
            this.Col_Channel4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Col_Channel4.HeaderText = "Channel4";
            this.Col_Channel4.MinimumWidth = 6;
            this.Col_Channel4.Name = "Col_Channel4";
            this.Col_Channel4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 5;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel7, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel6, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel5, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1305, 127);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Controls.Add(this.label4, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.textBox4, 0, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(1047, 3);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(255, 121);
            this.tableLayoutPanel7.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Lime;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Tahoma", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(249, 97);
            this.label4.TabIndex = 2;
            this.label4.Text = "Waiting";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox4
            // 
            this.textBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox4.Location = new System.Drawing.Point(3, 3);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(249, 25);
            this.textBox4.TabIndex = 1;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Controls.Add(this.label3, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.textBox3, 0, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(786, 3);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(255, 121);
            this.tableLayoutPanel6.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Lime;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Tahoma", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(249, 97);
            this.label3.TabIndex = 2;
            this.label3.Text = "Waiting";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox3
            // 
            this.textBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox3.Location = new System.Drawing.Point(3, 3);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(249, 25);
            this.textBox3.TabIndex = 1;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.textBox2, 0, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(525, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(255, 121);
            this.tableLayoutPanel5.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Lime;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Tahoma", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(249, 97);
            this.label2.TabIndex = 2;
            this.label2.Text = "Waiting";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox2
            // 
            this.textBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox2.Location = new System.Drawing.Point(3, 3);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(249, 25);
            this.textBox2.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel4);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(4, 4);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(253, 119);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Basic";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 4;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel4.Controls.Add(this.Channel4, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.Channel3, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.Channel2, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.Channel1, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label5, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.label6, 3, 1);
            this.tableLayoutPanel4.Controls.Add(this.label7, 3, 2);
            this.tableLayoutPanel4.Controls.Add(this.label8, 3, 3);
            this.tableLayoutPanel4.Controls.Add(this.labPass_Channel1, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.labPass_Channel2, 2, 1);
            this.tableLayoutPanel4.Controls.Add(this.labPass_Channel3, 2, 2);
            this.tableLayoutPanel4.Controls.Add(this.labPass_Channel4, 2, 3);
            this.tableLayoutPanel4.Controls.Add(this.labSUM_Channel4, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.labSUM_Channel3, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.labSUM_Channel2, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.labSUM_Channel1, 1, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(4, 24);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 4;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(245, 91);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // Channel4
            // 
            this.Channel4.AutoSize = true;
            this.Channel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Channel4.Location = new System.Drawing.Point(4, 66);
            this.Channel4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Channel4.Name = "Channel4";
            this.Channel4.Size = new System.Drawing.Size(53, 25);
            this.Channel4.TabIndex = 8;
            this.Channel4.Text = "0%";
            this.Channel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Channel3
            // 
            this.Channel3.AutoSize = true;
            this.Channel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Channel3.Location = new System.Drawing.Point(4, 44);
            this.Channel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Channel3.Name = "Channel3";
            this.Channel3.Size = new System.Drawing.Size(53, 22);
            this.Channel3.TabIndex = 7;
            this.Channel3.Text = "0%";
            this.Channel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Channel2
            // 
            this.Channel2.AutoSize = true;
            this.Channel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Channel2.Location = new System.Drawing.Point(4, 22);
            this.Channel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Channel2.Name = "Channel2";
            this.Channel2.Size = new System.Drawing.Size(53, 22);
            this.Channel2.TabIndex = 6;
            this.Channel2.Text = "0%";
            this.Channel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Channel1
            // 
            this.Channel1.AutoSize = true;
            this.Channel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Channel1.Location = new System.Drawing.Point(4, 0);
            this.Channel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Channel1.Name = "Channel1";
            this.Channel1.Size = new System.Drawing.Size(53, 22);
            this.Channel1.TabIndex = 5;
            this.Channel1.Text = "0%";
            this.Channel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(187, 0);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 22);
            this.label5.TabIndex = 0;
            this.label5.Text = "00:00";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Location = new System.Drawing.Point(187, 22);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 22);
            this.label6.TabIndex = 1;
            this.label6.Text = "00:00";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Location = new System.Drawing.Point(187, 44);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 22);
            this.label7.TabIndex = 2;
            this.label7.Text = "00:00";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Location = new System.Drawing.Point(187, 66);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 25);
            this.label8.TabIndex = 3;
            this.label8.Text = "00:00";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labPass_Channel1
            // 
            this.labPass_Channel1.AutoSize = true;
            this.labPass_Channel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labPass_Channel1.Location = new System.Drawing.Point(126, 0);
            this.labPass_Channel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labPass_Channel1.Name = "labPass_Channel1";
            this.labPass_Channel1.Size = new System.Drawing.Size(53, 22);
            this.labPass_Channel1.TabIndex = 4;
            this.labPass_Channel1.Text = "0";
            this.labPass_Channel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labPass_Channel2
            // 
            this.labPass_Channel2.AutoSize = true;
            this.labPass_Channel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labPass_Channel2.Location = new System.Drawing.Point(126, 22);
            this.labPass_Channel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labPass_Channel2.Name = "labPass_Channel2";
            this.labPass_Channel2.Size = new System.Drawing.Size(53, 22);
            this.labPass_Channel2.TabIndex = 4;
            this.labPass_Channel2.Text = "0";
            this.labPass_Channel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labPass_Channel3
            // 
            this.labPass_Channel3.AutoSize = true;
            this.labPass_Channel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labPass_Channel3.Location = new System.Drawing.Point(126, 44);
            this.labPass_Channel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labPass_Channel3.Name = "labPass_Channel3";
            this.labPass_Channel3.Size = new System.Drawing.Size(53, 22);
            this.labPass_Channel3.TabIndex = 4;
            this.labPass_Channel3.Text = "0";
            this.labPass_Channel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labPass_Channel4
            // 
            this.labPass_Channel4.AutoSize = true;
            this.labPass_Channel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labPass_Channel4.Location = new System.Drawing.Point(126, 66);
            this.labPass_Channel4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labPass_Channel4.Name = "labPass_Channel4";
            this.labPass_Channel4.Size = new System.Drawing.Size(53, 25);
            this.labPass_Channel4.TabIndex = 4;
            this.labPass_Channel4.Text = "0";
            this.labPass_Channel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labSUM_Channel4
            // 
            this.labSUM_Channel4.AutoSize = true;
            this.labSUM_Channel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labSUM_Channel4.Location = new System.Drawing.Point(65, 66);
            this.labSUM_Channel4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labSUM_Channel4.Name = "labSUM_Channel4";
            this.labSUM_Channel4.Size = new System.Drawing.Size(53, 25);
            this.labSUM_Channel4.TabIndex = 4;
            this.labSUM_Channel4.Text = "0";
            this.labSUM_Channel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labSUM_Channel3
            // 
            this.labSUM_Channel3.AutoSize = true;
            this.labSUM_Channel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labSUM_Channel3.Location = new System.Drawing.Point(65, 44);
            this.labSUM_Channel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labSUM_Channel3.Name = "labSUM_Channel3";
            this.labSUM_Channel3.Size = new System.Drawing.Size(53, 22);
            this.labSUM_Channel3.TabIndex = 4;
            this.labSUM_Channel3.Text = "0";
            this.labSUM_Channel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labSUM_Channel2
            // 
            this.labSUM_Channel2.AutoSize = true;
            this.labSUM_Channel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labSUM_Channel2.Location = new System.Drawing.Point(65, 22);
            this.labSUM_Channel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labSUM_Channel2.Name = "labSUM_Channel2";
            this.labSUM_Channel2.Size = new System.Drawing.Size(53, 22);
            this.labSUM_Channel2.TabIndex = 4;
            this.labSUM_Channel2.Text = "0";
            this.labSUM_Channel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labSUM_Channel1
            // 
            this.labSUM_Channel1.AutoSize = true;
            this.labSUM_Channel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labSUM_Channel1.Location = new System.Drawing.Point(65, 0);
            this.labSUM_Channel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labSUM_Channel1.Name = "labSUM_Channel1";
            this.labSUM_Channel1.Size = new System.Drawing.Size(53, 22);
            this.labSUM_Channel1.TabIndex = 4;
            this.labSUM_Channel1.Text = "0";
            this.labSUM_Channel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.textBox1, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.lab_Channel1, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(264, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(255, 121);
            this.tableLayoutPanel3.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Location = new System.Drawing.Point(3, 3);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(249, 25);
            this.textBox1.TabIndex = 2;
            // 
            // lab_Channel1
            // 
            this.lab_Channel1.AutoSize = true;
            this.lab_Channel1.BackColor = System.Drawing.Color.Lime;
            this.lab_Channel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lab_Channel1.Font = new System.Drawing.Font("Tahoma", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Channel1.Location = new System.Drawing.Point(3, 24);
            this.lab_Channel1.Name = "lab_Channel1";
            this.lab_Channel1.Size = new System.Drawing.Size(249, 97);
            this.lab_Channel1.TabIndex = 1;
            this.lab_Channel1.Text = "Waiting";
            this.lab_Channel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TestControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "TestControl";
            this.Size = new System.Drawing.Size(1311, 668);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTest)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private CCWin.SkinControl.SkinDataGridView dgvTest;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_TestKey;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_Channel1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_Channel2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_Channel3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_Channel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label Channel4;
        private System.Windows.Forms.Label Channel3;
        private System.Windows.Forms.Label Channel2;
        private System.Windows.Forms.Label Channel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label labPass_Channel1;
        private System.Windows.Forms.Label labPass_Channel2;
        private System.Windows.Forms.Label labPass_Channel3;
        private System.Windows.Forms.Label labPass_Channel4;
        private System.Windows.Forms.Label labSUM_Channel4;
        private System.Windows.Forms.Label labSUM_Channel3;
        private System.Windows.Forms.Label labSUM_Channel2;
        private System.Windows.Forms.Label labSUM_Channel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label lab_Channel1;
        private System.Windows.Forms.TextBox textBox1;
    }
}
